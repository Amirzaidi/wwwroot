<?php
class continent extends mysql
{
	protected function table()
	{
		return 'continents';
	}

	/*
	protected function intKey()
	{
		return 'id';
	}
	*/
}
?>