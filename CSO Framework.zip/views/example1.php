<?php

$country = new country('The Netherlands');
echo $country->desc;

?>